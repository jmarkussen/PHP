<?php


echo "Hvordan gjenopprette database? Gå inn i MyPHPAdmin, lag ny database med samme navn: 'modul7_test' og importer filen modul7_test.sql."


?>