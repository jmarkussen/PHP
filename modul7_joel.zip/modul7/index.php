<!DOCTYPE html>
<html lang="no">
<head>
  <title>Indeks for modul 7</title>
</head>
<body>

  <center>
    <h1>Indeks for modul 7</h1>
    <table>
      <tr><td><a href="oppgave7.1.php">Oppgave 1</a></td></tr>
      <tr><td><a href="oppgave7.2.php">Oppgave 2</a></td></tr>
      <tr><td><a href="oppgave7.3.php">Oppgave 3</a></td></tr>
      <tr><td><a href="oppgave7.4.php">Oppgave 4</a></td></tr>
      <tr><td><a href="oppgave7.5.php">Oppgave 5</a></td></tr>
    </table>
  </center>

</body>
</html>
