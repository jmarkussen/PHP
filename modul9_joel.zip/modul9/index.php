<!DOCTYPE html>
<html lang="no">
<head>
  <meta charset="UTF-8">
  <title>Indeks for modul 9</title>
</head>
<body>

  <center>
    <h1>Indeks for modul 9</h1>
    <table>
      <tr><td><a href="oppgave9.1.php">Oppgave 1</a></td></tr>
      <tr><td><a href="oppgave9.2.php">Oppgave 2</a></td></tr>
      <tr><td><a href="oppgave9.3.php">Oppgave 3</a></td></tr>
      <tr><td><a href="oppgave4/oppgave9.4.php">Oppgave 4</a></td></tr>
      <tr><td><a href="oppgave5/oppgave9.5.php">Oppgave 5</a></td></tr>
    </table>
  </center>

</body>
</html>
