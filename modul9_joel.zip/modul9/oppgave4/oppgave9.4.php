<!DOCTYPE html>
<html lang="no">
<head>
    <meta charset="UTF-8">
    <title>Nedlasting av filer</title>
</head>
<body>
<h1>Velg en fil å laste ned</h1>
<ul>
    <li><a href="download.php?file=tekst.pdf">Last ned tekst.pdf hvis du vil ha tesktdokument</a></li>
    <li><a href="download.php?file=bilder.pdf">Last ned bilder.pdf hvis du vil ha bilder</a></li>
</ul>
</body>
</html>
