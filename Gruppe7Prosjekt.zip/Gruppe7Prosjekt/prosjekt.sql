-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2025 at 05:45 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prosjekt`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat_responses`
--

CREATE TABLE `chat_responses` (
  `id` int(10) UNSIGNED NOT NULL,
  `intent` varchar(50) NOT NULL,
  `pattern` varchar(255) DEFAULT NULL,
  `response` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_responses`
--

INSERT INTO `chat_responses` (`id`, `intent`, `pattern`, `response`) VALUES
(2, 'store_price_lookup', 'hva koster\\s+(\\d{13})\\s+(hos|i|på)\\s+([A-Za-zÆØÅæøå ]+)', ''),
(3, 'product_description', '(?:hva er|beskrivelse|beskrivelse av|info om|fortell om)\\s*(\\d{13})\n', ''),
(4, 'greeting', '(hei|hallo|heisann|god dag|hello|halla)', 'Hei! Send meg en EAN-kode, så finner jeg den billigste prisen.'),
(5, 'thanks', '(takk|thanks|thank you)', 'Bare hyggelig! Si ifra hvis du trenger mer hjelp.'),
(6, 'capabilities', '(hva kan du|hjelp|hva kan du gjøre|hva kan du svare på)', 'Jeg kan finne priser og informasjon om matvarer basert på EAN-koder.'),
(7, 'unknown', NULL, 'Beklager, jeg forstod ikke helt. Prøv gjerne å sende en EAN-kode.');

-- --------------------------------------------------------

--
-- Table structure for table `ean_products`
--

CREATE TABLE `ean_products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `ean_code` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ean_products`
--

INSERT INTO `ean_products` (`id`, `product_name`, `ean_code`) VALUES
(1, 'Melkesjokolade 200g Freia\r\n', '7040110569908'),
(2, 'Meierismør 500g Tine', '7038010010187'),
(3, 'YT proteinyoghurt Vanilje, 430 g', '7038010068980'),
(4, 'Leverpostei 100g Stabburet', '7039010132435'),
(5, 'Norvegia 26% Skorpefri 500g', '7038010014604'),
(6, 'Monster Ultra White 0,5l boks', '5060337502238');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`) VALUES
(1, 'Hva koster [EAN]?'),
(3, 'Hva koster [EAN] hos [butikk]?'),
(4, 'Hjelp'),
(5, 'Fortell om [EAN]'),
(7, 'Hva kan du gjøre?');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL,
  `failed_attempts` int(11) DEFAULT 0,
  `last_failed_attempt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `username`, `password_hash`, `role`, `failed_attempts`, `last_failed_attempt`) VALUES
(5, 'Maja', 'Petterson', 'Majasp@mail.no', 'Majasp', '$2y$10$gVhUbX7LOZQKywW.q7eADOD0bzhT2VrjRl2Qkt73KAWXg3eIPy6wa', 'user', 0, NULL),
(6, 'admin', 'adminsen', 'admin@admin.no', 'admin', '$2y$10$TeP1mQAHy5svr9oAHOBF6.sKA97rQ0bINotXNM91GBalm9HpLlKXa', 'admin', 0, NULL),
(7, 'knut', 'knudsen', 'knutK@mail.no', 'Knuta', '$2y$10$b3zi3gtz/W7O2W2hsxsXXO6fTSeLfU7jhqKdTWVm7VyALDHszIjAm', 'user', 1, '2025-12-01 09:30:10'),
(8, 'Gran', 'Tre', 'Grantre@mail.no', 'Grantre', '$2y$10$Byzgv/L14M0URQC1HEJrB.pjuwj2PNA3IibxDb0ZEu8jyaUABBtcW', 'user', 0, NULL),
(9, 'Paul', 'Paulsen', 'Paul@mail.no', 'PaulP', '$2y$10$2gos1XnV.MGSHZM8iGPbteEi2FIuCg7RrxcY8SKO.AWJzyhrXQ7gy', 'user', 1, '2025-12-01 10:39:50'),
(10, 'Kai', 'Havna', 'Kai@mail.no', 'Kai', '$2y$10$l72sLlf7hLtGlPdrCg.Dq.0VXywexApHLIQ2SbVUP0bgbKo5LD5Ze', 'user', 0, NULL),
(11, 'Kål', 'Rabi', 'Kaalen@mail.no', 'Kålen', '$2y$10$5QBQu/flJaRC/61OYlSpqup/uslLQW0lcnFkvSSNkGJx8znuTg4gi', 'user', 3, '2025-12-01 17:27:34'),
(12, 'Markus', 'Markussen', 'Markus@mail.no', 'Marken', '$2y$10$NuK3CUzM2WIXVRMNJJfO8eOvJyRhah431BS0.69Z8OIdYqbCv3DVq', 'user', 0, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat_responses`
--
ALTER TABLE `chat_responses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ean_products`
--
ALTER TABLE `ean_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_responses`
--
ALTER TABLE `chat_responses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `ean_products`
--
ALTER TABLE `ean_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
