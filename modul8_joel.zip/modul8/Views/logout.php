<?php
// logout.php skal bare kalle $auth->logout()
// index.php har allerede lastet inn alle klassene og opprettet $auth

$auth->logout();
?>